﻿using System;
using System.Collections.Generic;
using System.Linq;

public class SortPersonStartUp
{

    static void Main()
    {
        


    }
}

