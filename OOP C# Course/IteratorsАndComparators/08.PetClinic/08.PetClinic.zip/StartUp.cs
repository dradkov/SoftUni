﻿
using System;
using System.Collections.Generic;

public class StartUp
{
    private static void Main(string[] args)
    {
       var engine  = new Engine();
        engine.Run();

    }
}
